package com.mrjoni.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors
import org.json.JSONObject

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var answer: TextView
    private lateinit var input: EditText
    private lateinit var apiKey: EditText
    private lateinit var tts: TextToSpeech
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        window.statusBarColor = android.graphics.Color.rgb(5, 12, 25)
        window.navigationBarColor = android.graphics.Color.BLACK

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(android.graphics.Color.rgb(5, 12, 25))
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 30f
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(0, 220, 255))
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL AI ASSISTANT"
            textSize = 12f
            letterSpacing = 0.2f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.LTGRAY)
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 92f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(0, 190, 255))
            setPadding(0, 16, 0, 6)
        }
        status = TextView(this).apply {
            text = "SYSTEM ONLINE • READY"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.GREEN)
        }
        input = EditText(this).apply {
            hint = "अपना सवाल लिखें..."
            setHintTextColor(android.graphics.Color.GRAY)
            setTextColor(android.graphics.Color.WHITE)
            setPadding(16, 12, 16, 12)
            setSingleLine(false)
            minLines = 2
            setBackgroundColor(android.graphics.Color.rgb(20, 35, 52))
        }
        val ask = Button(this).apply { text = "ASK JARVIS" }
        val voice = Button(this).apply { text = "🎙 बोलकर पूछें" }
        answer = TextView(this).apply {
            text = "नमस्ते! मैं JARVIS हूँ।\nपहले Settings में Gemini API Key डालें।"
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(8, 20, 8, 20)
        }
        apiKey = EditText(this).apply {
            hint = "Gemini API Key (केवल अपने फोन में)"
            setHintTextColor(android.graphics.Color.GRAY)
            setTextColor(android.graphics.Color.WHITE)
            setSingleLine(true)
            setText(prefs.getString("api_key", ""))
            setBackgroundColor(android.graphics.Color.rgb(20, 35, 52))
        }
        val save = Button(this).apply { text = "SAVE API KEY" }
        page.addView(title)
        page.addView(subtitle)
        page.addView(orb)
        page.addView(status)
        page.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 22 })
        page.addView(ask, LinearLayout.LayoutParams(-1, -2))
        page.addView(voice, LinearLayout.LayoutParams(-1, -2))
        page.addView(answer, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(apiKey, LinearLayout.LayoutParams(-1, -2))
        page.addView(save, LinearLayout.LayoutParams(-1, -2))
        setContentView(ScrollView(this).apply { addView(page) })

        save.setOnClickListener {
            prefs.edit().putString("api_key", apiKey.text.toString().trim()).apply()
            status.text = "API KEY SAVED"
        }
        ask.setOnClickListener { askJarvis(input.text.toString().trim()) }
        voice.setOnClickListener { startVoiceInput() }
    }

    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            answer.text = "इस फोन में Speech Recognition उपलब्ध नहीं है।"
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS को अपना सवाल बताएं")
        }
        try { startActivityForResult(intent, 42) } catch (_: Exception) {
            answer.text = "Voice input शुरू नहीं हो पाया।"
        }
    }

    @Deprecated("Deprecated by Android API; kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(words)
            askJarvis(words)
        }
    }

    private fun askJarvis(question: String) {
        if (question.isBlank()) { answer.text = "पहले अपना सवाल लिखें या बोलें।"; return }
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) { answer.text = "पहले नीचे Gemini API Key सेव करें।"; return }
        status.text = "THINKING..."
        answer.text = "JARVIS जवाब तैयार कर रहा है..."
        worker.execute {
            val result = try {
                val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" +
                    URLEncoder.encode(key, "UTF-8")
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                val body = JSONObject().put("contents",
                    org.json.JSONArray().put(JSONObject().put("parts",
                        org.json.JSONArray().put(JSONObject().put("text",
                            "तुम JARVIS नाम के सहायक हो। सरल हिंदी में उत्तर दो। सवाल: $question")))))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val raw = stream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = JSONObject(raw)
                json.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")
                    ?.optJSONObject(0)?.optString("text") ?: "जवाब नहीं मिला: $raw"
            } catch (e: Exception) { "कनेक्शन में समस्या: ${e.localizedMessage}" }
            runOnUiThread {
                answer.text = result
                status.text = "SYSTEM ONLINE • READY"
                if (!result.startsWith("कनेक्शन में समस्या")) tts.speak(result, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
            }
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        worker.shutdown()
        super.onDestroy()
    }
}
